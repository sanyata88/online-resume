/*
This is empty on purpose! Your code to build the resume will go here.
 */
 /*
 The var defines an object bio. Contains biographical information in form of lists for contacts and skills.
 */
 var bio = {
     'name': "Sanhita Rath",
     "role": "Web Developer",
     "contacts": {
         "mobile": "317-666-0887",
         "email": "sanyata88@gmail.com",
         "location": "Scottsdale, AZ",
         "github": "sanyata88"
     },
     "biopic": "images/sani.jpg",
     "welcomeMessage": "I am a highly motivated and driven individual seeking an opportunity as a web developer.",
     "skills": [
         "HTML", "CSS", "JavaScript", "Python"
     ]
 };
 /*
 Encapsulated function to display the object bio.%data% is replaced with desired entry by linking html and javasript.
 append helps to link respective info with the respective div on the html page.
 */
 bio.display = function() {
     var formattedName = HTMLheaderName.replace("%data%", bio.name);
     var formattedRole = HTMLheaderRole.replace("%data%", bio.role);
     var formattedMobile = HTMLmobile.replace("%data%", bio.contacts.mobile);
     var formattedEmail = HTMLemail.replace("%data%", bio.contacts.email);
     var formattedGithub = HTMLgithub.replace("%data%", bio.contacts.github);
     var formattedLocation = HTMLlocation.replace("%data%", bio.contacts.location);
     var formattedPic = HTMLbioPic.replace("%data%", bio.biopic);
     var formattedWelcome = HTMLwelcomeMsg.replace("%data%", bio.welcomeMessage);
     $("#header").prepend(formattedRole);
     $("#header").prepend(formattedName);

     $("#topContacts").append(formattedMobile);
     $("#topContacts").append(formattedEmail);
     $("#topContacts").append(formattedGithub);
     $("#topContacts").append(formattedLocation);

     $("#footerContacts").append(formattedMobile);
     $("#footerContacts").append(formattedEmail);
     $("#footerContacts").append(formattedGithub);
     $("#footerContacts").append(formattedLocation);

     $("#header").append(formattedPic);
     $("#header").append(formattedWelcome);
     /*the if ensures that the skills list is not empty.
     if not empty, it iterates through the list and displays all the skills
     */
     if (bio.skills.length > 0) {
         $("#header").append(HTMLskillsStart);
         bio.skills.forEach(function(skill) {
             var formattedSkill = HTMLskills.replace('%data%', skill);
             $("#skills").append(formattedSkill);
         });

     }
 };

 bio.display();
 /*
 variable work is defined. This contains an array of all the jobs*/
 var work = {
     "jobs": [{
         "employer": "ACTREC,Tata Memorial Center",
         "title": "Research Assistant",
         "location": "Navi Mumbai, INDIA",
         "dates": "June 2013 - Feb 2015",
         "description": "Performing pharmacological and genetic studies for generic drugs. Coordinating several clinical trials for Cancer research."
     }, {
         "employer": "Life Technologies",
         "title": "Research Assistant",
         "location": "Beverly,MA",
         "dates": "June 2012 - Dec 2012",
         "description": "I was part of a team optimizing Ion Chef - next generation sequencing and technology.Required skills involving emulsion PCR and DNA sequencing."
     }]
 };
 /*encapsulated function to display object work and its attributes
 The for loop iterates through the arrays in object work and displays the title, location, description for each job
 */
 work.display = function() {
     if (work.jobs.length > 0) {

         $("#workExperience").append(HTMLworkStart);
         work.jobs.forEach(function(job) {
             var formattedworkEmployer = HTMLworkEmployer.replace('%data%', job.employer);
             var formattedworkTitle = HTMLworkTitle.replace('%data%', job.title);
             var formattedEmployerWorkTitle = formattedworkEmployer + formattedworkTitle;
             $(".work-entry:last").append(formattedEmployerWorkTitle);
             var formattedworkLocation = HTMLworkLocation.replace('%data%', job.location);
             $(".work-entry:last").append(formattedworkLocation);
             var formattedworkDates = HTMLworkDates.replace('%data%', job.dates);
             $(".work-entry:last").append(formattedworkDates);
             var formattedworkDescription = HTMLworkDescription.replace('%data%', job.description);
             $(".work-entry:last").append(formattedworkDescription);
         });
     }
 };

 work.display();

 /*
 object education stores all the schools in an array */
 var education = {
     "schools": [{
         "name": "Northeastern University",
         "location": "Boston, MA",
         "degree": "Masters",
         "majors": "Biotechnology",
         "url" : "http://www.northeastern.edu/",
         "dates": '2013'
     }, {
         "name": "D.Y.Patil University",
         "location": "Navi Mumbai, India",
         "degree": "Bachelors",
         "majors": "Bioinformatics",
         "url" : "http://www.dypatil.edu/",
         "dates": '2010'
     }],
     "onlineCourses": [{
         "school": "udacity",
         "title": "Intro to programming",
         "dates": "October 2016",
         "url": "https://www.udacity.com/course/intro-to-programming-nanodegree--nd000"
     }]
 };
 /*
 encapsulated function to display all schools within object education
 */
 education.display = function() {
     if (education.schools.length > 0) {
         education.schools.forEach(function(school) {
             $("#education").append(HTMLschoolStart);
             var formattedschoolName = HTMLschoolName.replace('%data%', school.name).replace('#',school.url);
             var formattedschoolDegree = HTMLschoolDegree.replace('%data%', school.degree);
             $(".education-entry:last").append(formattedschoolName + formattedschoolDegree);
             var formattedschoolLocation = HTMLschoolLocation.replace('%data%', school.location);
             $(".education-entry:last").append(formattedschoolLocation);
             var formattedschoolMajor = HTMLschoolMajor.replace('%data%', school.majors);
             $(".education-entry:last").append(formattedschoolMajor);
             var formattedschoolDates = HTMLschoolDates.replace('%data%', school.dates);
             $(".education-entry:last").append(formattedschoolDates);
         });
     }
     if (education.onlineCourses.length > 0) {

         $("#education").append(HTMLonlineClasses);

         education.onlineCourses.forEach(function(course) {
             $("#education").append(HTMLschoolStart);
             var formattedOnlineTitle = HTMLonlineTitle.replace("%data%", course.title);
             var formattedOnlineSchool = HTMLonlineSchool.replace("%data%", course.school);
             $(".education-entry:last").append(formattedOnlineTitle + formattedOnlineSchool);
             var formattedOnlineDates = HTMLonlineDates.replace("%data%", course.dates);
             $(".education-entry:last").append(formattedOnlineDates);
             var formattedOnlineURL = HTMLonlineURL.replace("%data%", course.url);
             $(".education-entry:last").append(formattedOnlineURL);

         });

     }

 };
 education.display();

 var projects = {
     "projects": [{
         "title": "Building my own website",
         "dates": "October 2016",
         "description": "I built my own website using HTML and CSS",
         "images": ["images/web.png"],
         "url": "file:///Users/orvc/Desktop/udacity/stage1/mywebpage.html"
     }, {
         "title": "Building a movie webpage",
         "dates": "October 2016",
         "description": "I built a movie website displaying trailers of my favourite movies using python",
         "images": ["images/movies.png"],
         "url": "file:///Users/orvc/Desktop/udacity/movies/fresh_tomatoes.html"
     }, {
         "title": "Building an online resume",
         "dates": "October 2016",
         "description": "I built an online resume using javascript, HTML and CSS",
         "images": ["images/resume.png"],
         "url": "file:///Users/orvc/Desktop/udacity/frontend-nanodegree-resume-master/index.html"
     }, {
         "title": "MadLibs Generator",
         "dates": "October 2016",
         "description": "programmed a mad lib game using python",
         "images": ["images/Madlibs.jpg"],
         "url": "file:///Users/orvc/Desktop/udacity/frontend-nanodegree-resume-master/index.html"

     }]
 };

 /*
 this encapsulated function also uses the dot notation to display all attributes of object project
 */
 projects.display = function() {
   if(education.schools.length > 0 || education.onlineCourses.length > 0) {
     for (project = 0 ; project < projects.projects.length ; project++) {
         $("#projects").append(HTMLprojectStart);

         var formattedTitle = HTMLprojectTitle.replace("%data%", projects.projects[project].title);
         $(".project-entry:last").append(formattedTitle);

         var formattedDates = HTMLprojectDates.replace("%data%", projects.projects[project].dates);
         $(".project-entry:last").append(formattedDates);

         var formattedDescription = HTMLworkDescription.replace("%data%", projects.projects[project].description);
         $(".project-entry:last").append(formattedDescription);

         if (projects.projects[project].images.length > 0){
           for (i = 0; i < projects.projects[project].images.length ; i++) {
             var formattedImage = HTMLprojectImage.replace("%data%", projects.projects[project].images[i]);
             $(".project-entry:last").append(formattedImage);
         }
       }

     }
  }
};
projects.display();

 // Maps
 $('#mapDiv').append(googleMap);
